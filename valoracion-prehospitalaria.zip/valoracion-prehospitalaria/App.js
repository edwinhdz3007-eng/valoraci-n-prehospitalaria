import React, { useState, useMemo } from 'react';
import { SafeAreaView, View, Text, TouchableOpacity, ScrollView, TextInput, StyleSheet, Share, Alert } from 'react-native';
import InputRow from './src/components/InputRow';
import { gcsAdult, gcsPediatric, rts, qsofa, safeNumber } from './src/utils/calculators';
import { buildFRAP } from './src/utils/frap';

const TabButton = ({ label, active, onPress }) => (
  <TouchableOpacity onPress={onPress} style={[styles.tabBtn, active && styles.tabBtnActive]}>
    <Text style={[styles.tabBtnText, active && styles.tabBtnTextActive]}>{label}</Text>
  </TouchableOpacity>
);

export default function App(){
  const [tab, setTab] = useState("Inicial");

  // Datos del paciente y evaluación
  const [demographics, setDemographics] = useState({ name:"", age:"", sex:"", chiefComplaint:"" });

  // Inicial
  const [initial, setInitial] = useState({
    massiveHemorrhage: false, airway:"Permeable", breathing:"Adecuada", circulation:"Estable", disability:"Orientado",
    exposure:"Sin hallazgos", SAMPLE:"", PQRST:""
  });

  // Secundaria
  const [secondary, setSecondary] = useState({ headToToe:"Sin deformidades, dolor o lesiones aparentes." });

  // Vitals
  const [vitals, setVitals] = useState({ hr:"", rr:"", sbp:"", dbp:"", spo2:"", temp:"", glu:"" });

  // Escalas
  const [gcsEye, setGcsEye] = useState("4");
  const [gcsVerbal, setGcsVerbal] = useState("5");
  const [gcsVerbalPeds, setGcsVerbalPeds] = useState("5");
  const [gcsMotor, setGcsMotor] = useState("6");
  const [usePedsVerbal, setUsePedsVerbal] = useState(false);

  const gcsResult = useMemo(() => {
    if (usePedsVerbal) {
      const r = gcsPediatric({ eye: Number(gcsEye), verbalPeds: Number(gcsVerbalPeds), motor: Number(gcsMotor) });
      return { total: r.total, clas: r.clas };
    } else {
      const r = gcsAdult({ eye: Number(gcsEye), verbal: Number(gcsVerbal), motor: Number(gcsMotor) });
      return { total: r.total, clas: r.clas };
    }
  }, [gcsEye, gcsVerbal, gcsVerbalPeds, gcsMotor, usePedsVerbal]);

  const rtsResult = useMemo(() => {
    const g = gcsResult.total || 15;
    const s = safeNumber(vitals.sbp, 120);
    const rrate = safeNumber(vitals.rr, 16);
    return rts({ gcs: g, sbp: s, rr: rrate });
  }, [gcsResult, vitals.sbp, vitals.rr]);

  const qsofaResult = useMemo(() => {
    const rrate = safeNumber(vitals.rr, 0);
    const s = safeNumber(vitals.sbp, 0);
    const g = gcsResult.total ?? 15;
    return qsofa({ rr: rrate, sbp: s, gcs: g });
  }, [vitals.rr, vitals.sbp, gcsResult]);

  const [times, setTimes] = useState({ callTime: "", arrivalTime: "", departSceneTime: "", hospitalArrivalTime: "" });
  const [interventions, setInterventions] = useState({ text: "" });
  const [notes, setNotes] = useState("");

  const scalesForReport = {
    gcsTotal: gcsResult.total,
    gcsClas: gcsResult.clas,
    rtsScore: rtsResult.score,
    qsofaPts: qsofaResult.pts,
    qsofaRisk: qsofaResult.riesgo
  };

  const reportText = useMemo(() => buildFRAP({
    demographics, initial, secondary, vitals, scales: scalesForReport, times, interventions, notes
  }), [demographics, initial, secondary, vitals, scalesForReport, times, interventions, notes]);

  const shareReport = async () => {
    try {
      await Share.share({ message: reportText });
    } catch (e) {
      Alert.alert("Error al compartir", e?.message || String(e));
    }
  };

  const renderInicial = () => (
    <ScrollView style={styles.page} contentContainerStyle={{paddingBottom: 100}}>
      <Text style={styles.section}>Datos del paciente</Text>
      <InputRow label="Nombre" value={demographics.name} onChangeText={v=>setDemographics({...demographics, name:v})} />
      <View style={{ flexDirection:'row', gap: 8 }}>
        <InputRow label="Edad" value={demographics.age} onChangeText={v=>setDemographics({...demographics, age:v})} keyboardType="numeric" />
        <InputRow label="Sexo" value={demographics.sex} onChangeText={v=>setDemographics({...demographics, sex:v})} />
      </View>
      <InputRow label="Motivo de atención" value={demographics.chiefComplaint} onChangeText={v=>setDemographics({...demographics, chiefComplaint:v})} />

      <Text style={styles.section}>XABCDE</Text>
      <View style={styles.rowWrap}>
        <TouchableOpacity style={[styles.chip, initial.massiveHemorrhage && styles.chipOn]} onPress={()=>setInitial({...initial, massiveHemorrhage: !initial.massiveHemorrhage})}>
          <Text style={styles.chipText}>X Hemorragia masiva</Text>
        </TouchableOpacity>
      </View>
      <InputRow label="A - Vía aérea" value={initial.airway} onChangeText={v=>setInitial({...initial, airway:v})} />
      <InputRow label="B - Respiración" value={initial.breathing} onChangeText={v=>setInitial({...initial, breathing:v})} />
      <InputRow label="C - Circulación" value={initial.circulation} onChangeText={v=>setInitial({...initial, circulation:v})} />
      <InputRow label="D - Déficit neurológico" value={initial.disability} onChangeText={v=>setInitial({...initial, disability:v})} />
      <InputRow label="E - Exposición" value={initial.exposure} onChangeText={v=>setInitial({...initial, exposure:v})} />

      <Text style={styles.section}>SAMPLE / PQRST</Text>
      <InputRow label="SAMPLE" value={initial.SAMPLE} onChangeText={v=>setInitial({...initial, SAMPLE:v})} placeholder="Alergias, Medicación, AP, Última ingesta, Eventos..." />
      <InputRow label="PQRST" value={initial.PQRST} onChangeText={v=>setInitial({...initial, PQRST:v})} placeholder="Dolor: Provoca, Calidad, Región, Severidad, Tiempo" />

      <Text style={styles.section}>Signos vitales</Text>
      <View style={{ flexDirection:'row', gap: 8 }}>
        <InputRow label="FC (lpm)" value={vitals.hr} onChangeText={v=>setVitals({...vitals, hr:v})} keyboardType="numeric" />
        <InputRow label="FR (rpm)" value={vitals.rr} onChangeText={v=>setVitals({...vitals, rr:v})} keyboardType="numeric" />
      </View>
      <View style={{ flexDirection:'row', gap: 8 }}>
        <InputRow label="PAS (mmHg)" value={vitals.sbp} onChangeText={v=>setVitals({...vitals, sbp:v})} keyboardType="numeric" />
        <InputRow label="PAD (mmHg)" value={vitals.dbp} onChangeText={v=>setVitals({...vitals, dbp:v})} keyboardType="numeric" />
      </View>
      <View style={{ flexDirection:'row', gap: 8 }}>
        <InputRow label="SpO₂ (%)" value={vitals.spo2} onChangeText={v=>setVitals({...vitals, spo2:v})} keyboardType="numeric" />
        <InputRow label="Temp (°C)" value={vitals.temp} onChangeText={v=>setVitals({...vitals, temp:v})} keyboardType="numeric" />
      </View>
      <InputRow label="Glucosa (mg/dL)" value={vitals.glu} onChangeText={v=>setVitals({...vitals, glu:v})} keyboardType="numeric" />
    </ScrollView>
  );

  const renderSecundaria = () => (
    <ScrollView style={styles.page} contentContainerStyle={{paddingBottom: 100}}>
      <Text style={styles.section}>Exploración de cabeza a pies</Text>
      <TextInput
        style={styles.multiline}
        value={secondary.headToToe}
        onChangeText={v=>setSecondary({...secondary, headToToe:v})}
        multiline
        numberOfLines={8}
        placeholder="Deformidades, Contusiones, Abrasiones, Punciones, Quemaduras, Laceraciones, Hinchazón..."
        placeholderTextColor="#999"
      />
      <Text style={styles.section}>Intervenciones</Text>
      <TextInput
        style={styles.multiline}
        value={interventions.text}
        onChangeText={v=>setInterventions({text:v})}
        multiline
        numberOfLines={6}
        placeholder="Vía aérea, O₂, control hemorragias, inmovilización, glucosa, analgesia, etc."
        placeholderTextColor="#999"
      />
      <Text style={styles.section}>Tiempos</Text>
      <InputRow label="Llamada (YYYY-MM-DD HH:mm)" value={times.callTime} onChangeText={v=>setTimes({...times, callTime:v})} placeholder="2025-08-17 12:00" />
      <InputRow label="Arribo escena" value={times.arrivalTime} onChangeText={v=>setTimes({...times, arrivalTime:v})} placeholder="2025-08-17 12:10" />
      <InputRow label="Salida escena" value={times.departSceneTime} onChangeText={v=>setTimes({...times, departSceneTime:v})} placeholder="2025-08-17 12:25" />
      <InputRow label="Arribo hospital" value={times.hospitalArrivalTime} onChangeText={v=>setTimes({...times, hospitalArrivalTime:v})} placeholder="2025-08-17 12:45" />
      <Text style={styles.section}>Notas</Text>
      <TextInput
        style={styles.multiline}
        value={notes}
        onChangeText={setNotes}
        multiline
        numberOfLines={6}
        placeholder="Hallazgos relevantes, evolución y respuesta al tratamiento."
        placeholderTextColor="#999"
      />
    </ScrollView>
  );

  const renderEscalas = () => (
    <ScrollView style={styles.page} contentContainerStyle={{paddingBottom: 100}}>
      <Text style={styles.section}>Glasgow Coma Scale</Text>
      <View style={{flexDirection:'row', gap:8}}>
        <InputRow label="Ocular (1-4)" value={gcsEye} onChangeText={setGcsEye} keyboardType="numeric" />
        {!usePedsVerbal ? (
          <InputRow label="Verbal (1-5)" value={gcsVerbal} onChangeText={setGcsVerbal} keyboardType="numeric" />
        ) : (
          <InputRow label="Verbal Ped. (1-5)" value={gcsVerbalPeds} onChangeText={setGcsVerbalPeds} keyboardType="numeric" />
        )}
        <InputRow label="Motora (1-6)" value={gcsMotor} onChangeText={setGcsMotor} keyboardType="numeric" />
      </View>
      <View style={styles.rowWrap}>
        <TouchableOpacity style={[styles.chip, usePedsVerbal && styles.chipOn]} onPress={()=>setUsePedsVerbal(!usePedsVerbal)}>
          <Text style={styles.chipText}>Usar verbal pediátrica</Text>
        </TouchableOpacity>
      </View>
      <Text style={styles.result}>GCS total: {gcsResult.total} — {gcsResult.clas}</Text>

      <Text style={styles.section}>RTS (Revised Trauma Score)</Text>
      <Text style={styles.hint}>Se calcula a partir de GCS, PAS y FR.</Text>
      <Text style={styles.result}>RTS: {rtsResult.score}  (cod: GCS {rtsResult.coded.gcs}, PAS {rtsResult.coded.sbp}, FR {rtsResult.coded.rr})</Text>

      <Text style={styles.section}>qSOFA</Text>
      <Text style={styles.hint}>Criterios: FR ≥22, PAS ≤100, GCS &lt;15.</Text>
      <Text style={styles.result}>qSOFA: {qsofaResult.pts} — Riesgo {qsofaResult.riesgo}</Text>
    </ScrollView>
  );

  const renderReporte = () => (
    <ScrollView style={styles.page} contentContainerStyle={{paddingBottom: 120}}>
      <Text style={styles.section}>Reporte FRAP</Text>
      <TextInput
        style={[styles.multiline, {minHeight: 320}]}
        editable={false}
        value={reportText}
        multiline
      />
      <TouchableOpacity style={styles.primaryBtn} onPress={shareReport}>
        <Text style={styles.primaryBtnText}>Compartir reporte</Text>
      </TouchableOpacity>
    </ScrollView>
  );

  return (
    <SafeAreaView style={{ flex:1, backgroundColor:'#fff' }}>
      <View style={styles.header}>
        <Text style={styles.title}>Valoración Prehospitalaria</Text>
      </View>

      <View style={styles.tabBar}>
        {["Inicial", "Secundaria", "Escalas", "Reporte"].map(t => (
          <TabButton key={t} label={t} active={tab===t} onPress={()=>setTab(t)} />
        ))}
      </View>

      <View style={{ flex:1 }}>
        {tab==="Inicial" && renderInicial()}
        {tab==="Secundaria" && renderSecundaria()}
        {tab==="Escalas" && renderEscalas()}
        {tab==="Reporte" && renderReporte()}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  header: { padding: 16, borderBottomWidth: 1, borderBottomColor: '#eee' },
  title: { fontSize: 18, fontWeight: '600', textAlign: 'center' },
  tabBar: { flexDirection: 'row', borderBottomWidth: 1, borderBottomColor:'#eee' },
  tabBtn: { flex:1, paddingVertical: 12, alignItems:'center' },
  tabBtnActive: { borderBottomWidth: 3, borderBottomColor: '#333' },
  tabBtnText: { color:'#666' },
  tabBtnTextActive: { color:'#000', fontWeight:'700' },

  page: { flex:1, padding: 16 },
  section: { fontSize: 16, fontWeight: '700', marginTop: 8, marginBottom: 8 },
  rowWrap: { flexDirection: 'row', flexWrap:'wrap', gap: 8, marginBottom: 8 },
  chip: { paddingVertical: 8, paddingHorizontal: 12, borderRadius: 16, backgroundColor:'#eee' },
  chipOn: { backgroundColor:'#cde7ff' },
  chipText: { color:'#111' },
  hint: { fontSize: 12, color:'#666', marginBottom: 4 },
  result: { fontSize: 16, marginBottom: 8 },

  multiline: { borderWidth:1, borderColor:'#ccc', borderRadius:8, padding:10, textAlignVertical:'top', minHeight:120, fontSize:14 },

  primaryBtn: { backgroundColor:'#111', padding:14, borderRadius:10, marginTop: 12, alignItems:'center' },
  primaryBtnText: { color:'#fff', fontWeight:'600' }
});