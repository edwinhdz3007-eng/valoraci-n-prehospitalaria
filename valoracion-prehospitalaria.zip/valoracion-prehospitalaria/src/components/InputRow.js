import React from 'react';
import { View, Text, TextInput, StyleSheet } from 'react-native';

export default function InputRow({ label, value, onChangeText, keyboardType="default", placeholder="", flex=1 }){
  return (
    <View style={styles.row}>
      <Text style={styles.label}>{label}</Text>
      <TextInput
        style={[styles.input, {flex}]}
        value={value}
        onChangeText={onChangeText}
        keyboardType={keyboardType}
        placeholder={placeholder}
        placeholderTextColor="#999"
      />
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  label: { width: 140, fontSize: 14, color: '#222' },
  input: { borderWidth: 1, borderColor: '#ccc', padding: 8, borderRadius: 8, fontSize: 14 }
});