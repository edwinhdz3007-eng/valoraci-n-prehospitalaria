// Escalas y utilidades de cálculo

// Glasgow Coma Scale (adulto)
export function gcsAdult({ eye=1, verbal=1, motor=1 } = {}) {
  const total = (Number(eye)||0) + (Number(verbal)||0) + (Number(motor)||0);
  let clas = "Grave";
  if (total >= 13) clas = "Leve";
  else if (total >= 9) clas = "Moderado";
  return { total, clas };
}

// Glasgow pediátrico (verbal pediátrico)
export function gcsPediatric({ eye=1, verbalPeds=1, motor=1 } = {}) {
  const total = (Number(eye)||0) + (Number(verbalPeds)||0) + (Number(motor)||0);
  let clas = "Grave";
  if (total >= 13) clas = "Leve";
  else if (total >= 9) clas = "Moderado";
  return { total, clas };
}

// RTS - Revised Trauma Score
// Codificación (GCS, PAS, FR) y fórmula: 0.9368*GCS_c + 0.7326*PAS_c + 0.2908*FR_c
function rtsCodeGCS(gcs){
  if (gcs >= 13) return 4;
  if (gcs >= 9) return 3;
  if (gcs >= 6) return 2;
  if (gcs >= 4) return 1;
  return 0;
}
function rtsCodeSBP(sbp){
  if (sbp > 89) return 4;
  if (sbp > 76) return 3;
  if (sbp > 50) return 2;
  if (sbp > 1) return 1;
  return 0;
}
function rtsCodeRR(rr){
  if (rr >= 10 && rr <= 29) return 4;
  if (rr > 29) return 3;
  if (rr >= 6) return 2;
  if (rr > 0) return 1;
  return 0;
}
export function rts({ gcs=15, sbp=120, rr=16 } = {}){
  const cG = rtsCodeGCS(Number(gcs));
  const cS = rtsCodeSBP(Number(sbp));
  const cR = rtsCodeRR(Number(rr));
  const score = +(0.9368*cG + 0.7326*cS + 0.2908*cR).toFixed(2);
  return { score, coded: { gcs:cG, sbp:cS, rr:cR } };
}

// qSOFA
export function qsofa({ rr=0, sbp=0, gcs=15 } = {}){
  let pts = 0;
  if (Number(rr) >= 22) pts++;
  if (Number(sbp) <= 100) pts++;
  if (Number(gcs) < 15) pts++;
  let riesgo = "Bajo";
  if (pts >= 2) riesgo = "Alto";
  else if (pts === 1) riesgo = "Intermedio";
  return { pts, riesgo };
}

// Ayudas
export function safeNumber(v, def=0){
  const n = Number(v);
  return Number.isFinite(n) ? n : def;
}