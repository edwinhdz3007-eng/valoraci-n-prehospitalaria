export function buildFRAP({ demographics, initial, secondary, vitals, scales, times, interventions, notes }){
  const now = new Date();
  const fmt = (d)=> d ? new Date(d).toLocaleString() : "-";
  const yesNo = (v)=> v ? "Sí" : "No";
  const lines = [];

  lines.push("=== FRAP - Valoración Prehospitalaria ===");
  lines.push(`Fecha/Hora reporte: ${now.toLocaleString()}`);

  lines.push("\n--- Datos del paciente ---");
  lines.push(`Nombre: ${demographics?.name||"-"}`);
  lines.push(`Edad: ${demographics?.age||"-"}  Sexo: ${demographics?.sex||"-"}`);
  lines.push(`Motivo de atención: ${demographics?.chiefComplaint||"-"}`);
  lines.push(`Antecedentes (SAMPLE): ${initial?.SAMPLE||"-"}`);
  lines.push(`Dolor (PQRST): ${initial?.PQRST||"-"}`);

  lines.push("\n--- Valoración inicial (XABCDE) ---");
  lines.push(`Hemorragia exanguinante controlada: ${yesNo(initial?.massiveHemorrhage)}`);
  lines.push(`A: Vía aérea ${initial?.airway||"-"}`);
  lines.push(`B: Respiración ${initial?.breathing||"-"}`);
  lines.push(`C: Circulación ${initial?.circulation||"-"}`);
  lines.push(`D: Déficit neurológico ${initial?.disability||"-"}`);
  lines.push(`E: Exposición ${initial?.exposure||"-"}`);

  lines.push("\n--- Valoración secundaria ---");
  lines.push(`Exploración cefalocaudal: ${secondary?.headToToe||"-"}`);
  lines.push(`Glucosa capilar: ${vitals?.glu||"-"} mg/dL`);

  lines.push("\n--- Signos vitales ---");
  lines.push(`FC: ${vitals?.hr||"-"} lpm   FR: ${vitals?.rr||"-"} rpm   SpO2: ${vitals?.spo2||"-"} %`);
  lines.push(`Tensión arterial: ${vitals?.sbp||"-"}/${vitals?.dbp||"-"} mmHg   Temp: ${vitals?.temp||"-"} °C`);
  lines.push(`Glasgow: ${scales?.gcsTotal||"-"} (${scales?.gcsClas||"-"})  RTS: ${scales?.rtsScore||"-"}  qSOFA: ${scales?.qsofaPts||"-"} (${scales?.qsofaRisk||"-"})`);

  lines.push("\n--- Intervenciones ---");
  lines.push(interventions?.text || "-");

  lines.push("\n--- Tiempos ---");
  lines.push(`Llamada: ${fmt(times?.callTime)}  Arribo: ${fmt(times?.arrivalTime)}  Salida escena: ${fmt(times?.departSceneTime)}  Arribo hospital: ${fmt(times?.hospitalArrivalTime)}`);

  lines.push("\n--- Notas ---");
  lines.push(notes || "-");

  return lines.join("\n");
}