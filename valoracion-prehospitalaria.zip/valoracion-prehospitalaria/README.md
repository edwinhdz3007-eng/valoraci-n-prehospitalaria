# Valoración Prehospitalaria (Android / iOS con Expo)
App sencilla para la **valoración inicial y secundaria**, con **cálculo de escalas** (GCS adulto/pediátrica, RTS, qSOFA) y **reporte tipo FRAP** listo para compartir.

## Requisitos
- Node.js LTS
- Expo CLI (`npm i -g expo`)
- App **Expo Go** en tu Android/iPhone

## Inicio rápido
```bash
cd valoracion-prehospitalaria
npm install
expo start
```
Escanea el QR con **Expo Go**.

## Estructura
- `App.js`: navegación por pestañas (custom) y estado global simple.
- `src/components/InputRow.js`: filas de entrada reutilizables.
- `src/utils/calculators.js`: funciones para GCS, RTS y qSOFA.
- `src/utils/frap.js`: generador de texto FRAP (reporte).
- `assets/icon.png`: icono.

> Sin librerías externas: funciona directo en **Expo Go**.